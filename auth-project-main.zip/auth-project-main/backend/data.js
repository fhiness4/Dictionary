
const products = [
    {
        item: 'Dildo',
        price: 200,
        date: new Date().getTime(),
        id:1
    },
    {
        item: 'lubricant',
        price: 300,
        date: new Date().getTime(),
        id:2
    },
    {
        item: 'Doll',
        price: 600,
         date : new Date().getTime(),
        id:3
    },
    {
        item: 'sex toy',
         date : new Date().getTime(),
        price: 400,
        id:4
    }
]

module.exports = {products}